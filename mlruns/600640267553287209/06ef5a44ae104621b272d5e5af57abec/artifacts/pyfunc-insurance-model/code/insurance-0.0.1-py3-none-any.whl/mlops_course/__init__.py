"""Initialize the MLOps course package.

This file marks the directory as a Python package.
"""
